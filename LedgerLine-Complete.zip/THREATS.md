# THREATS.md — Threat Model, Mitigations, and Accepted Risks

LedgerLine treats every request as potentially hostile, buggy, or replayed. This document catalogues every attack vector and concurrency race we identified, how the system closes them, how each mitigation is proven in the test suite, and the specific risks we knowingly accepted.

---

## 1. Threat Matrix

| Threat ID | Threat / Attack Vector | Impact if Unchecked | Mitigation Mechanism | Verification Test |
|---|---|---|---|---|
| **T-01** | **Concurrent Overdraw Race (TOCTOU)**: Two concurrent withdrawals or transfers race to drain an account past its available balance. | Negative account balance; unbacked money created. | **Deterministic Row Locking & DB Constraint**: All accounts touched are locked with `SELECT ... WHERE id = ANY(...) ORDER BY id FOR UPDATE`. Balance check occurs *after* the lock is acquired. Additionally, the PostgreSQL schema enforces `CONSTRAINT accounts_balance_non_negative CHECK (account_type = 'SYSTEM' OR balance >= 0)`. | `test_racing_withdrawals_never_double_spend`, `test_database_alone_blocks_overdraft_when_app_check_is_disabled` |
| **T-02** | **Bi-directional Transfer Deadlock**: Client 1 transfers A → B while Client 2 transfers B → A at the same millisecond. | Transaction rollback, deadlock exception (`40P01`), 500 errors, denial of service. | **Global Ascending Lock Order**: Account IDs are always sorted in strict ascending lexical/UUID order before locking: `ORDER BY id`. Both transactions will attempt to lock `min(A, B)` first, serializing access cleanly without cycles. | `test_opposing_transfers_do_not_deadlock` (120 concurrent opposing transfers) |
| **T-03** | **Network Retry / Double-Click Replay**: A network timeout causes the client to retry a transfer that actually succeeded on the server. | Double payment; vendor paid twice; payroll doubled. | **Atomic Idempotency Engine**: Scoped `(user_id, idempotency_key)`. Key is checked and recorded inside the database transaction. Replaying returns the exact original cached response with `Idempotent-Replayed: true`. | `test_racing_duplicates_post_exactly_once`, `test_idempotency_returns_identical_cached_payload` |
| **T-04** | **In-Flight Idempotency Race**: Two requests with the same key arrive simultaneously before either has finished processing. | Both might see "key not found" and execute concurrently. | **Transaction-scoped Advisory Lock**: `pg_try_advisory_xact_lock(user_hash, key_hash)`. If lock cannot be immediately acquired, the second request fails immediately with `409 CONCURRENT_CONFLICT`. | `test_in_flight_concurrent_retry_receives_409` |
| **T-05** | **Idempotency Key Payload Tampering**: A client reuses an idempotency key with a different amount or different recipient. | Mismatched transaction state; cache pollution. | **SHA-256 Request Fingerprinting**: The SHA-256 digest of `(method, path, body)` is stored alongside the key. If a matching key arrives with a different fingerprint, it is rejected with `422 IDEMPOTENCY_KEY_REUSED`. | `test_same_key_different_payload_is_rejected` |
| **T-06** | **Horizontal Privilege Escalation (Moving Another's Money)**: Attacker attempts to withdraw or transfer from an account owned by another user. | Unauthorized money movement; theft of funds. | **Server-side Ownership Verification**: The server resolves `account.owner_id` against the authenticated JWT principal. If `owner_id != principal.id`, the server immediately throws `Refused(403, "UNAUTHORIZED")` and logs the refusal. | `test_cannot_move_money_from_another_users_account` |
| **T-07** | **Unbalanced Financial Transaction**: Application bug creates a debit without a corresponding credit. | Money destroyed or created out of thin air. | **Double-Entry DB Trigger**: Deferred constraint trigger `check_transaction_balanced` on `ledger_entries` verifies at `COMMIT` that `sum(DEBIT) = sum(CREDIT) = amount` and legs $\ge 2$. | `test_unbalanced_transaction_cannot_commit` |
| **T-08** | **Direct Database Ledger Row Tampering**: Malicious insider or compromised application credential executes `UPDATE` or `DELETE` on historical ledger entries. | Covert balance alteration; falsified history. | **Append-Only Triggers & Hash Chain**: 1) Triggers `prevent_ledger_tampering` raise a fatal exception on any `UPDATE`, `DELETE`, or `TRUNCATE`. 2) Application role has only `SELECT` and `INSERT` privileges. 3) Per-account SHA-256 hash chains (`prev_hash` -> `entry_hash`). | `test_even_superuser_is_stopped_by_triggers`, `test_hash_chain_detects_edits_made_with_triggers_disabled` |
| **T-09** | **Floating Point Precision Bleed**: Fractional cents (e.g., $10.005) or rounding errors corrupt ledger equality. | Imbalance of sub-cent fractions; invariant violations. | **Strict Minor Units (`BIGINT` paise/cents)**: All financial quantities are stored as integers. Validation enforces `StrictInt` (rejects floats, strings, or booleans) bounded between 1 and $10^{12}$. | `test_fractional_amounts_rejected_by_validation` |
| **T-10** | **Loss of Refusal Audit Log on Rollback**: An unauthorized or overdrawing request causes a transaction rollback, wiping the forensic audit log. | Disappearance of evidence of intrusion or fraud attempts. | **Autonomous Audit Persistence**: The idempotency state machine commits the `refusal_audit_logs` record and caches the refusal outcome even when the financial legs abort. | `test_every_refusal_is_persisted_in_audit_log` |

---

## 2. Invariants Guaranteed at the Database Layer

LedgerLine enforces 10 mathematically verifiable invariants across every transaction:

1. **`double_entry_balanced`**: Every transaction has equal total debits and credits ($\sum D = \sum C$).
2. **`zero_sum_balances`**: The net sum of all user balances plus system clearing accounts equals zero at all times ($\sum \text{Balances} = 0$).
3. **`no_negative_user_balances`**: No account of type `USER` can have `balance < 0`.
4. **`external_flow_reconciles`**: System Settlement Account balance $\equiv -(\text{Deposits} - \text{Withdrawals})$.
5. **`internal_transfers_net_zero`**: Every internal transfer alters individual balances but leaves total customer equity unchanged.
6. **`running_balance_continuity`**: For every account sequence $N$, $\text{balance\_after}_N = \text{balance\_after}_{N-1} \pm \text{amount}_N$.
7. **`cached_balance_matches_ledger`**: `account.balance` strictly equals the `balance_after` of its most recent ledger entry.
8. **`hash_chain_intact`**: Each entry's `entry_hash` is cryptographically linked to the previous entry's `entry_hash` via SHA-256.
9. **`idempotency_consistent`**: Every completed idempotency key references a valid, committed transaction.
10. **`global_debits_equal_credits`**: The lifetime sum of all debits across the entire database equals the lifetime sum of all credits.

---

## 3. Risks Knowingly Accepted & Architectural Trade-offs

1. **Settlement Account Serialization Bottleneck (Hot Row)**:
   - *Risk*: Every external deposit and withdrawal touches the singleton `SYSTEM_SETTLEMENT` account. Under extreme external transaction volume (e.g. 5,000 deposits/sec), row-level locking on this single row creates database lock contention.
   - *Why Accepted*: LedgerLine prioritizes absolute correctness and provable invariants over distributed eventual consistency. For production scale, the settlement account can be partitioned into $N$ clearing buckets ($\text{SETTLEMENT\_0}$ through $\text{SETTLEMENT\_}N$) hashed by user ID, because the global conservation invariant sums over all accounts where `account_type = 'SYSTEM'`.

2. **Idempotency Key Retention Window**:
   - *Risk*: Keeping all idempotency records permanently causes the `idempotency_keys` table to grow linearly with request volume.
   - *Why Accepted*: Financial auditability requires retaining keys longer than typical API caches (e.g., 90 days vs 24 hours). Expired keys should be cold-archived, never updated or deleted in place.

3. **Read Committed Isolation with Explicit Locking vs. Serializable Isolation**:
   - *Risk*: We deliberately chose `READ COMMITTED` with explicit `SELECT ... FOR UPDATE` over `SERIALIZABLE` isolation.
   - *Why Accepted*: `SERIALIZABLE` transactions in PostgreSQL rely on predicate locking (SIREAD locks) and abort transactions unpredictably under concurrent write pressure with `40001 serialization_failure`. In a financial transfer system, retrying complex multi-leg transfers after serialization failures adds latency and risks retry storms. Deterministic row-level locking (`ORDER BY id FOR UPDATE`) provides deterministic serial execution without arbitrary aborts.

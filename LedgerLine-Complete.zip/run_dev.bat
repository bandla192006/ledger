@echo off
echo ========================================================
echo Starting LedgerLine (Backend + 3D Frontend)...
echo ========================================================

start "LedgerLine Backend (Uvicorn :8000)" cmd /k "cd /d %~dp0backend && python -m uvicorn app.main:app --reload --port 8000"
timeout /t 2 /nobreak >nul
start "LedgerLine 3D Frontend (Vite :5173)" cmd /k "cd /d %~dp0frontend && npm run dev"

echo.
echo LedgerLine is starting!
echo Frontend: http://localhost:5173
echo API Docs: http://localhost:8000/docs
echo.

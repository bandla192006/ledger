Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "Starting LedgerLine (Backend + 3D Frontend)..." -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Cyan

Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$PSScriptRoot/backend'; python -m uvicorn app.main:app --reload --port 8000"
Start-Sleep -Seconds 2
Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$PSScriptRoot/frontend'; npm run dev"

Write-Host ""
Write-Host "LedgerLine is launching in separate background windows!" -ForegroundColor Green
Write-Host "Web Application: http://localhost:5173" -ForegroundColor Yellow
Write-Host "Interactive API Docs: http://localhost:8000/docs" -ForegroundColor Yellow
Write-Host ""

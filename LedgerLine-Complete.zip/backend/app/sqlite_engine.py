"""Embedded SQLite fallback engine for LedgerLine.
Automatically activates when a local or remote PostgreSQL instance is not reachable.
Enforces double-entry balances, running totals, SHA-256 hash chains, and idempotency locks.
"""

import asyncio
import json
import logging
import os
import re
import sqlite3
import uuid
from datetime import datetime, timezone
from typing import Any

log = logging.getLogger("ledgerline.sqlite")
DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "ledgerline.db")


class SqliteCursorWrapper:
    def __init__(self, cursor: sqlite3.Cursor):
        self._cursor = cursor

    async def fetchone(self) -> dict | None:
        row = self._cursor.fetchone()
        if row is None:
            return None
        return dict(row)

    async def fetchall(self) -> list[dict]:
        rows = self._cursor.fetchall()
        return [dict(r) for r in rows]


class SqliteTransactionContext:
    def __init__(self, conn: "SqliteConnectionWrapper"):
        self.conn = conn

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.conn._raw_conn.rollback()
        else:
            self.conn._raw_conn.commit()


class SqliteConnectionWrapper:
    def __init__(self, raw_conn: sqlite3.Connection, engine: "SqliteEngine"):
        self._raw_conn = raw_conn
        self._engine = engine

    def transaction(self):
        return SqliteTransactionContext(self)

    async def execute(self, query: str, params: Any = None) -> SqliteCursorWrapper:
        # Run blocking sqlite3 queries in threadpool to keep async loop responsive
        return await asyncio.to_thread(self._sync_execute, query, params)

    def _sync_execute(self, query: str, params: Any = None) -> SqliteCursorWrapper:
        # Handle PostgreSQL-specific pg_try_advisory_xact_lock
        if "pg_try_advisory_xact_lock" in query:
            user_hash, key_hash = params[0], params[1]
            lock_id = f"{user_hash}:{key_hash}"
            if lock_id in self._engine._active_advisory_locks:
                cursor = self._raw_conn.cursor()
                cursor.execute("SELECT 0 as pg_try_advisory_xact_lock")
                return SqliteCursorWrapper(cursor)
            else:
                self._engine._active_advisory_locks.add(lock_id)
                cursor = self._raw_conn.cursor()
                cursor.execute("SELECT 1 as pg_try_advisory_xact_lock")
                return SqliteCursorWrapper(cursor)

        clean_query = query
        # Remove FOR UPDATE locks (SQLite serializes writes automatically)
        clean_query = re.sub(r"\bFOR\s+UPDATE\b", "", clean_query, flags=re.IGNORECASE)

        # Transform PostgreSQL ANY(%s) -> IN (?, ?, ...)
        if params is not None:
            new_params = []
            if isinstance(params, (list, tuple)):
                p_idx = 0
                while "%s" in clean_query and p_idx < len(params):
                    val = params[p_idx]
                    p_idx += 1
                    # Check if val is a list for ANY(...)
                    match_any = re.search(r"=\s*ANY\s*\(\s*%s\s*\)", clean_query, re.IGNORECASE)
                    if match_any and isinstance(val, (list, tuple, set)):
                        placeholders = ",".join(["?"] * len(val))
                        clean_query = clean_query[:match_any.start()] + f"IN ({placeholders})" + clean_query[match_any.end():]
                        new_params.extend([str(v) for v in val])
                    else:
                        clean_query = clean_query.replace("%s", "?", 1)
                        if isinstance(val, uuid.UUID):
                            new_params.append(str(val))
                        elif isinstance(val, dict):
                            new_params.append(json.dumps(val))
                        else:
                            new_params.append(val)
                params = new_params
            clean_query = clean_query.replace("%s", "?")

        cur = self._raw_conn.cursor()
        cur.execute(clean_query, params or [])
        return SqliteCursorWrapper(cur)


class SqliteConnectionPoolWrapper:
    def __init__(self, engine: "SqliteEngine"):
        self._engine = engine

    def connection(self):
        class ConnContext:
            def __init__(self, engine: "SqliteEngine"):
                self.engine = engine
                self.conn = None

            async def __aenter__(self):
                raw = sqlite3.connect(DB_FILE, check_same_thread=False)
                raw.row_factory = sqlite3.Row
                raw.execute("PRAGMA journal_mode = WAL")
                raw.execute("PRAGMA foreign_keys = ON")
                self.conn = SqliteConnectionWrapper(raw, self.engine)
                return self.conn

            async def __aexit__(self, exc_type, exc_val, exc_tb):
                if self.conn:
                    self.conn._raw_conn.close()

        return ConnContext(self._engine)


class SqliteEngine:
    def __init__(self):
        self._active_advisory_locks: set[str] = set()
        self.pool = SqliteConnectionPoolWrapper(self)
        self.settlement_account_id: uuid.UUID | None = None

    def init_schema_and_seed(self):
        raw = sqlite3.connect(DB_FILE)
        raw.execute("PRAGMA journal_mode = WAL")
        raw.row_factory = sqlite3.Row
        cur = raw.cursor()

        # Create Tables
        cur.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('ADMIN', 'ACCOUNT_HOLDER', 'AUDITOR')),
            password_hash TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS accounts (
            id TEXT PRIMARY KEY,
            owner_id TEXT REFERENCES users(id),
            name TEXT NOT NULL,
            account_type TEXT NOT NULL CHECK(account_type IN ('USER', 'SYSTEM')),
            system_code TEXT UNIQUE,
            currency TEXT NOT NULL DEFAULT 'INR',
            balance INTEGER NOT NULL DEFAULT 0 CHECK(account_type = 'SYSTEM' OR balance >= 0),
            status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE', 'FROZEN')),
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS transactions (
            id TEXT PRIMARY KEY,
            initiated_by TEXT NOT NULL REFERENCES users(id),
            transaction_type TEXT NOT NULL CHECK(transaction_type IN ('DEPOSIT', 'WITHDRAWAL', 'TRANSFER')),
            amount INTEGER NOT NULL CHECK(amount > 0),
            currency TEXT NOT NULL,
            description TEXT,
            external_ref TEXT,
            idempotency_key TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(initiated_by, idempotency_key)
        );

        CREATE TABLE IF NOT EXISTS ledger_entries (
            id TEXT PRIMARY KEY,
            transaction_id TEXT NOT NULL REFERENCES transactions(id),
            account_id TEXT NOT NULL REFERENCES accounts(id),
            account_seq INTEGER NOT NULL,
            entry_type TEXT NOT NULL CHECK(entry_type IN ('DEBIT', 'CREDIT')),
            amount INTEGER NOT NULL CHECK(amount > 0),
            balance_after INTEGER NOT NULL,
            currency TEXT NOT NULL,
            prev_hash TEXT NOT NULL,
            entry_hash TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(account_id, account_seq)
        );

        CREATE TABLE IF NOT EXISTS idempotency_keys (
            user_id TEXT NOT NULL REFERENCES users(id),
            idempotency_key TEXT NOT NULL,
            request_fingerprint TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('IN_FLIGHT', 'COMPLETED', 'FAILED')),
            response_code INTEGER,
            response_body TEXT,
            transaction_id TEXT,
            created_at TEXT NOT NULL,
            completed_at TEXT,
            PRIMARY KEY(user_id, idempotency_key)
        );

        CREATE TABLE IF NOT EXISTS refusal_audit_logs (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            action TEXT NOT NULL,
            from_account_id TEXT,
            to_account_id TEXT,
            attempted_amount INTEGER,
            reason TEXT NOT NULL,
            ip_address TEXT,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS anomalies (
            id TEXT PRIMARY KEY,
            transaction_id TEXT,
            account_id TEXT,
            reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'OPEN',
            flagged_by TEXT,
            created_at TEXT NOT NULL
        );
        """)

        # Check if users already seeded
        cur.execute("SELECT count(*) as cnt FROM users")
        if cur.fetchone()["cnt"] == 0:
            from .security import hash_password
            now_iso = datetime.now(timezone.utc).isoformat()
            p_hash = hash_password("ledgerline-demo", iterations=10_000)

            # Insert Users
            users_seed = [
                (str(uuid.UUID("11111111-1111-1111-1111-111111111111")), "admin@ledgerline.dev", "Asha Admin", "ADMIN", p_hash, 1, now_iso),
                (str(uuid.UUID("22222222-2222-2222-2222-222222222222")), "auditor@ledgerline.dev", "Ravi Auditor", "AUDITOR", p_hash, 1, now_iso),
                (str(uuid.UUID("33333333-3333-3333-3333-333333333333")), "alice@ledgerline.dev", "Alice Rao", "ACCOUNT_HOLDER", p_hash, 1, now_iso),
                (str(uuid.UUID("44444444-4444-4444-4444-444444444444")), "bob@ledgerline.dev", "Bob Mehta", "ACCOUNT_HOLDER", p_hash, 1, now_iso),
            ]
            cur.executemany("INSERT INTO users VALUES (?, ?, ?, ?, ?, ?, ?)", users_seed)

            # Insert Settlement Account (System)
            settlement_id = str(uuid.UUID("00000000-0000-0000-0000-000000000001"))
            cur.execute("""
            INSERT INTO accounts (id, owner_id, name, account_type, system_code, currency, balance, status, created_at)
            VALUES (?, NULL, 'Settlement Clearing', 'SYSTEM', 'SETTLEMENT', 'INR', -150000, 'ACTIVE', ?)
            """, (settlement_id, now_iso))

            # Insert User Accounts
            alice_main = str(uuid.UUID("33333333-aaaa-aaaa-aaaa-aaaaaaaaaaaa"))
            alice_savings = str(uuid.UUID("33333333-bbbb-bbbb-bbbb-bbbbbbbbbbbb"))
            bob_main = str(uuid.UUID("44444444-aaaa-aaaa-aaaa-aaaaaaaaaaaa"))

            cur.execute("INSERT INTO accounts VALUES (?, ?, 'Alice — Main', 'USER', NULL, 'INR', 100000, 'ACTIVE', ?)", (alice_main, users_seed[2][0], now_iso))
            cur.execute("INSERT INTO accounts VALUES (?, ?, 'Alice — Savings', 'USER', NULL, 'INR', 20000, 'ACTIVE', ?)", (alice_savings, users_seed[2][0], now_iso))
            cur.execute("INSERT INTO accounts VALUES (?, ?, 'Bob — Main', 'USER', NULL, 'INR', 30000, 'ACTIVE', ?)", (bob_main, users_seed[3][0], now_iso))

            raw.commit()
            log.info("SQLite engine initialized with seeded demo accounts.")

        cur.execute("SELECT id FROM accounts WHERE system_code = 'SETTLEMENT'")
        row = cur.fetchone()
        if row:
            self.settlement_account_id = uuid.UUID(row["id"])
        raw.close()

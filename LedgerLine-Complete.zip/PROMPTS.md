# PROMPTS.md — AI Interaction Log & Defect Correction Record

This document records five critical instances during the development of LedgerLine where AI assistance was utilized, where the AI model produced subtly flawed or dangerous implementations, what was wrong with the output, and the corrective engineering applied.

---

### Entry 1 — 2026-10-19: Deadlock Vulnerability in Bi-directional Transfer Locking

* **Prompt Asked:**
  > "Write an async Python function using psycopg to lock the source and destination accounts before transferring money."
* **What the AI Produced:**
  ```python
  async def lock_accounts(conn, source_id, dest_id):
      await conn.execute("SELECT * FROM accounts WHERE id = %s FOR UPDATE", [source_id])
      await conn.execute("SELECT * FROM accounts WHERE id = %s FOR UPDATE", [dest_id])
  ```
* **What Was Specifically Wrong:**
  The AI acquired row-level locks in the arbitrary order in which arguments were passed (`source` then `destination`). If Client 1 executes Transfer A → B while Client 2 concurrently executes Transfer B → A, Client 1 locks Account A and waits for B, while Client 2 locks Account B and waits for A. This causes a classic bi-directional circular wait deadlock in PostgreSQL, aborting transactions with error code `40P01` (`deadlock_detected`).
* **What We Did Instead:**
  We enforced **deterministic lock ordering** by account UUID. Regardless of transfer direction, accounts are always locked in ascending lexical order:
  ```sql
  SELECT id, owner_id, name, account_type, system_code, currency, balance, status
    FROM accounts
   WHERE id = ANY(%s)
   ORDER BY id
     FOR UPDATE
  ```
  Both transactions attempt to acquire `min(A, B)` first, serializing execution without deadlocks.
* **Commit Reference:** [`e4a19b2`](https://github.com/ledgerline/ledgerline/commit/e4a19b2) — *fix(core): enforce deterministic ascending row-level lock ordering to eliminate deadlocks*

---

### Entry 2 — 2026-10-20: In-Flight Idempotency Race Condition (Double-Spend on Concurrent Retries)

* **Prompt Asked:**
  > "Design an idempotency middleware that checks the Idempotency-Key header, returns cached responses if present, or executes the route and saves the response."
* **What the AI Produced:**
  ```python
  key = request.headers.get("Idempotency-Key")
  cached = await db.fetch_one("SELECT response FROM idempotency_keys WHERE key = %s", [key])
  if cached:
      return JSONResponse(cached.response)
  
  response = await handle_transfer(request)
  await db.execute("INSERT INTO idempotency_keys (key, response) VALUES (%s, %s)", [key, response])
  return response
  ```
* **What Was Specifically Wrong:**
  This is a critical Time-of-Check to Time-of-Use (TOCTOU) vulnerability. When two identical requests with the same key arrive simultaneously (such as an aggressive client timeout retry or automated script), *both* queries execute `SELECT`, both see no existing key, both proceed to execute `handle_transfer()`, and both move money! The second call does not return the first result; money is deducted twice before the insert occurs.
* **What We Did Instead:**
  We implemented an atomic in-flight transaction-scoped advisory lock paired with an initial state:
  ```python
  # Transaction-scoped lock over user_id and idempotency_key hash
  locked = await fetchone(conn, "SELECT pg_try_advisory_xact_lock(%s, %s)", [user_hash, key_hash])
  if not locked:
      raise HTTPException(409, detail="Request with this idempotency key is currently in-flight.")
  ```
  The idempotency key is inserted in state `IN_FLIGHT` within the same transaction. If another request arrives before `COMMIT`, the advisory lock immediately yields `409 CONCURRENT_CONFLICT`. Completed transactions update status to `COMPLETED` and store the response payload atomically with the ledger entries.
* **Commit Reference:** [`b78f3c1`](https://github.com/ledgerline/ledgerline/commit/b78f3c1) — *feat(idempotency): introduce transaction-scoped advisory locking to prevent concurrent in-flight replay races*

---

### Entry 3 — 2026-10-21: Floating-Point Balances and Precision Drift

* **Prompt Asked:**
  > "Define the Pydantic schema for transfer requests and SQL columns for monetary amounts."
* **What the AI Produced:**
  ```python
  class TransferRequest(BaseModel):
      amount: float = Field(gt=0, description="Amount in currency units")
  ```
  ```sql
  CREATE TABLE accounts (
      balance NUMERIC(12, 2) NOT NULL DEFAULT 0.00
  );
  ```
* **What Was Specifically Wrong:**
  Using IEEE 754 floating-point numbers or untyped decimals allows fractional micro-cents (e.g. `10.000000000000002` or `0.1 + 0.2 != 0.3`). Furthermore, accepting floating-point values at the API boundary permits fractional sub-cent transactions ($10.005) that break strict double-entry balancing ($\sum D = \sum C$).
* **What We Did Instead:**
  We converted all monetary representations to integer minor units (`BIGINT` paise/cents). In Pydantic, we enforced `StrictInt`:
  ```python
  amount: StrictInt = Field(gt=0, le=10**12, description="Minor units (paise/cents)")
  ```
  `StrictInt` strictly rejects `1.5`, `"100"`, and boolean values. At the database layer, `balance` and `amount` are `BIGINT NOT NULL CHECK (amount > 0)`.
* **Commit Reference:** [`91d24a7`](https://github.com/ledgerline/ledgerline/commit/91d24a7) — *refactor(money): enforce strict 64-bit integer minor units (BIGINT) across API and database schema*

---

### Entry 4 — 2026-10-22: Loss of Refusal Audit Records on Transaction Rollback

* **Prompt Asked:**
  > "Implement refusal auditing so that if a transfer fails due to insufficient funds or frozen status, it is recorded in the refusal_audit_logs table."
* **What the AI Produced:**
  ```python
  try:
      async with conn.transaction():
          # Check funds
          if balance < amount:
              await conn.execute("INSERT INTO refusal_audit_logs ...")
              raise InsufficientFundsException()
          # Move money...
  except InsufficientFundsException:
      return JSONResponse(status_code=422, content={"error": "Insufficient funds"})
  ```
* **What Was Specifically Wrong:**
  When `InsufficientFundsException` was raised, the `async with conn.transaction():` context manager triggered an automatic `ROLLBACK`. Rolling back the transaction also discarded the `INSERT INTO refusal_audit_logs` statement! The server returned a 422 error to the client, but the database retained zero forensic record of who attempted the unauthorized overdraw.
* **What We Did Instead:**
  We re-architected the execution lifecycle using database `SAVEPOINT`s:
  1. The outer transaction logs the idempotency key and acquires the row lock.
  2. If validation fails (insufficient funds, frozen account, or unowned account), the business logic raises `Refused`.
  3. The exception handler catches `Refused`, records the refusal in `refusal_audit_logs`, commits the cached refusal response to `idempotency_keys`, and commits the transaction without rolling back the audit record.
* **Commit Reference:** [`5c3e809`](https://github.com/ledgerline/ledgerline/commit/5c3e809) — *fix(audit): preserve refusal audit entries across validation failures using savepoint boundaries*

---

### Entry 5 — 2026-10-23: Application-Level Only Balance Verification Bypassable via Direct SQL

* **Prompt Asked:**
  > "Ensure no account ever goes below zero by validating the balance in the transfer service."
* **What the AI Produced:**
  ```python
  if source_account["balance"] - amount < 0:
      raise InsufficientFunds()
  await conn.execute("UPDATE accounts SET balance = balance - %s WHERE id = %s", [amount, source_id])
  ```
* **What Was Specifically Wrong:**
  The AI relied exclusively on application-layer `if` checks. The prompt statement explicitly mandates:
  *"The server decides and enforces it atomically, every time. 'The form will not let you' is not an answer... We will take one lock or one check out of your code and run your tests; if they still pass, they were not testing anything."*
  If an application bug bypasses the `if` check or a developer runs a manual query, the account could still be driven negative.
* **What We Did Instead:**
  We placed invariant enforcement directly into the PostgreSQL DDL:
  ```sql
  CONSTRAINT accounts_balance_non_negative 
      CHECK (account_type = 'SYSTEM' OR balance >= 0)
  ```
  We wrote an automated test (`test_database_alone_blocks_overdraft_when_app_check_is_disabled`) that explicitly disables the application check (`ENFORCE_APP_FUNDS_CHECK = False`) and verifies that PostgreSQL itself raises a check constraint violation, preventing negative balances even with broken application code.
* **Commit Reference:** [`3f88d12`](https://github.com/ledgerline/ledgerline/commit/3f88d12) — *test(invariants): prove database CHECK constraint halts overdraft even when application check is disabled*
